# -*- coding: utf-8 -*-
"""
YouTube Parser — fetches transcripts and metadata.
"""

import logging
import requests
from bs4 import BeautifulSoup

from .base import BaseParser, ParseResult, is_youtube_url, extract_youtube_video_id

logger = logging.getLogger("riocloud_reader.parsers.youtube")


class YouTubeParser(BaseParser):
    """Extract transcripts and metadata from YouTube videos."""
    
    name = "youtube"
    preferred_langs = ["en", "zh-Hans", "zh-Hant", "zh", "ja", "ko"]
    
    def can_handle(self, url: str) -> bool:
        return is_youtube_url(url)
    
    async def parse(self, url: str) -> ParseResult:
        """Parse a YouTube URL."""
        video_id = extract_youtube_video_id(url)
        if not video_id:
            return ParseResult.failure(url, "Invalid YouTube URL")
        
        # Get metadata
        title, author, description = await self._fetch_metadata(url)
        
        # Get transcript
        transcript_text, transcript_lang = await self._fetch_transcript(video_id)
        
        content_parts = []
        
        if transcript_lang:
            content_parts.append(f"*Transcript language: {transcript_lang}*\n")
        
        if transcript_text:
            content_parts.append(transcript_text)
        else:
            content_parts.append("> No transcript available for this video.")
        
        if description:
            content_parts.append(f"\n\n---\n\n**Description:**\n{description}")
        
        content = "\n".join(content_parts)
        
        return ParseResult(
            url=url,
            title=title or f"YouTube ({video_id})",
            content=content,
            author=author,
            tags=["youtube", "video"],
        )
    
    async def _fetch_metadata(self, url: str) -> tuple:
        """Fetch video metadata from the page."""
        try:
            resp = requests.get(url, headers=self._get_headers(), timeout=self.timeout)
            resp.raise_for_status()
            
            soup = BeautifulSoup(resp.text, "html.parser")
            
            # Title
            title = ""
            og_title = soup.find("meta", property="og:title")
            if og_title:
                title = og_title.get("content", "")
            if not title:
                title_tag = soup.find("title")
                title = title_tag.get_text(strip=True) if title_tag else ""
                if title.endswith(" - YouTube"):
                    title = title[:-10].strip()
            
            # Author
            author = ""
            link_author = soup.find("link", attrs={"itemprop": "name"})
            if link_author:
                author = link_author.get("content", "")
            
            # Description
            description = ""
            og_desc = soup.find("meta", property="og:description")
            if og_desc:
                description = og_desc.get("content", "")
            
            return title, author, description
            
        except Exception as e:
            logger.warning(f"Metadata fetch failed: {e}")
            return "", "", ""
    
    async def _fetch_transcript(self, video_id: str) -> tuple:
        """Fetch transcript for a video."""
        try:
            from youtube_transcript_api import YouTubeTranscriptApi
            
            transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
            
            # Try preferred languages
            transcript = None
            lang_code = ""
            
            for lang in self.preferred_langs:
                try:
                    transcript = transcript_list.find_manually_created_transcript([lang])
                    lang_code = lang
                    break
                except:
                    continue
            
            # Auto-generated fallback
            if not transcript:
                for lang in self.preferred_langs:
                    try:
                        transcript = transcript_list.find_generated_transcript([lang])
                        lang_code = f"{lang} (auto)"
                        break
                    except:
                        continue
            
            if transcript:
                entries = transcript.fetch()
                lines = [e["text"] for e in entries]
                return self._format_transcript(lines), lang_code
            
        except ImportError:
            logger.warning("youtube_transcript_api not installed")
        except Exception as e:
            logger.warning(f"Transcript fetch failed: {e}")
        
        return "", ""
    
    def _format_transcript(self, lines: list) -> str:
        """Format transcript into paragraphs."""
        if not lines:
            return ""
        
        paragraphs = []
        current = []
        sentence_count = 0
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            current.append(line)
            if any(line.endswith(p) for p in ".!?。！？"):
                sentence_count += 1
            if sentence_count >= 5:
                paragraphs.append(" ".join(current))
                current = []
                sentence_count = 0
        
        if current:
            paragraphs.append(" ".join(current))
        
        return "\n\n".join(paragraphs)
